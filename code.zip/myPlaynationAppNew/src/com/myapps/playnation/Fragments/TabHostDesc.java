package com.myapps.playnation.Fragments;

import android.support.v4.app.Fragment;

public class TabHostDesc extends Fragment {
	
	
	public void switchToTab(int tabIndex)
	{
		
	}

}
