package com.myapps.playnation.Classes;

public interface NewsFeedItem {
	public boolean isSection();
}
