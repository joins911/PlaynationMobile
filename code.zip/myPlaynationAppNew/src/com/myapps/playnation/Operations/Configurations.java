package com.myapps.playnation.Operations;

public class Configurations {

	public static boolean isLoginCheckEnabled = false;
	public static boolean isViewPagerSwipeEnable = false;
	public static String serverIp = "87.55.208.165:1337";
}
